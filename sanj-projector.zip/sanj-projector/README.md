# Sanj Properties — Price Projector

AI-powered property price history & 5-year projection tool for Indore real estate.

## Deploy to Netlify (FREE — 2 minutes)

1. Go to https://app.netlify.com
2. Sign up / log in (free)
3. Click "Add new site" → "Deploy manually"
4. Drag and drop the entire `sanj-projector` folder onto the page
5. Wait ~60 seconds → your site is LIVE at a URL like `https://amazing-name-123.netlify.app`
6. Optional: Go to Site Settings → Domain Management → add custom name

## Deploy to Vercel (FREE — 2 minutes)

1. Go to https://vercel.com
2. Sign up / log in (free)
3. Click "Add New Project" → "Browse" → upload this folder
4. Click Deploy → done!

## First-time use

When you open the app, enter your Anthropic API key once.
Get it from: https://console.anthropic.com/account/keys
The key is saved in your browser — you only need to enter it once.

## Adding new projects

Send the updated Google Sheet link to Claude and ask to regenerate the app.
